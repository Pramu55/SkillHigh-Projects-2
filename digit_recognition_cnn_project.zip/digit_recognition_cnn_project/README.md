# Handwritten Digit Recognition with CNN

## Project Overview
This project implements a Convolutional Neural Network (CNN) using TensorFlow/Keras to recognize handwritten digits from the MNIST dataset. It is designed as a complete, production‑ready pipeline—from data loading and preprocessing, through model training and evaluation, to an interactive Streamlit app for real‑time digit prediction.

## Directory Structure
```
digit_recognition_cnn_project/
├── app/
│   └── app.py              # Streamlit user interface
├── models/                 # Saved model files (*.h5, *.keras)
├── notebooks/
│   └── digit_recognition_workflow.ipynb
├── src/
│   ├── train.py            # Train and save the CNN
│   └── evaluate.py         # Evaluate a saved model
├── requirements.txt
└── README.md
```

## Setup
```bash
# 1. Create and activate a virtual environment (recommended)
python -m venv .venv
source .venv/bin/activate  # On Windows use .venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt
```

## Usage

### Training
```bash
python src/train.py  --epochs 10  --model_path models/digit_cnn.h5
```
* Adjust `--epochs` as desired. The MNIST dataset will be downloaded automatically on first run.*

### Evaluation
```bash
python src/evaluate.py --model_path models/digit_cnn.h5
```

### Streamlit App
```bash
streamlit run app/app.py
```
*Draw a digit in the canvas or upload a 28×28 PNG, and the model will predict the digit.*

## Real‑World Application
The approach shown here can be extended to Optical Character Recognition (OCR) systems beyond digits, enabling automatic reading of handwritten forms, bank cheques, postal mail sorting, and more.

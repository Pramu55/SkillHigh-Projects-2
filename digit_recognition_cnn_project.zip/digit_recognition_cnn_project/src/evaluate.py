"""Evaluate a saved CNN model on the MNIST test set."""
import argparse
import tensorflow as tf

def main(model_path):
    (x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()
    x_test = x_test.astype('float32') / 255.0
    x_test = x_test[..., None]

    model = tf.keras.models.load_model(model_path)
    test_loss, test_acc = model.evaluate(x_test, y_test, verbose=2)
    print(f"Test accuracy: {test_acc:.4f}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate MNIST CNN")
    parser.add_argument("--model_path", type=str,
                        default="models/digit_cnn.h5",
                        help="Path to the saved model")
    args = parser.parse_args()
    main(args.model_path)

import streamlit as st
from streamlit_drawable_canvas import st_canvas
import numpy as np
from PIL import Image, ImageOps
import tensorflow as tf
import tempfile
import os

st.set_page_config(page_title="MNIST Digit Recognition", layout="centered")
st.title("🖍️ Handwritten Digit Recognition")

model_path = st.sidebar.text_input(
    "Path to model (.h5 or .keras)",
    value="models/digit_cnn.h5"
)

@st.cache_resource
def load_model(path):
    return tf.keras.models.load_model(path)

if not os.path.exists(model_path):
    st.error("Model file not found. Train a model first or check the path.")
    st.stop()

model = load_model(model_path)

option = st.selectbox("Input Method", ["Draw", "Upload PNG (28×28)"])

if option == "Draw":
    st.write("Draw a digit (0‑9) below:")
    canvas_result = st_canvas(
        fill_color="white",
        stroke_width=10,
        stroke_color="black",
        background_color="white",
        height=280,
        width=280,
        drawing_mode="freedraw",
        key="canvas",
    )
    if st.button("Predict"):
        if canvas_result.image_data is not None:
            img = canvas_result.image_data
            # Convert RGBA to grayscale
            img = Image.fromarray((255 - img[:, :, 3]).astype(np.uint8))
            img = img.resize((28, 28)).convert("L")
            img_arr = np.array(img).astype('float32') / 255.0
            img_arr = img_arr.reshape(1, 28, 28, 1)
            pred = np.argmax(model.predict(img_arr), axis=1)[0]
            st.success(f"Predicted Digit: {pred}")
        else:
            st.warning("Draw something first!")
else:
    uploaded = st.file_uploader("Upload a 28×28 grayscale PNG", type=["png"])
    if uploaded and st.button("Predict"):
        img = Image.open(uploaded).convert("L")
        img = ImageOps.invert(img)  # Invert colors if needed
        img = img.resize((28, 28))
        img_arr = np.array(img).astype('float32') / 255.0
        img_arr = img_arr.reshape(1, 28, 28, 1)
        pred = np.argmax(model.predict(img_arr), axis=1)[0]
        st.success(f"Predicted Digit: {pred}")
